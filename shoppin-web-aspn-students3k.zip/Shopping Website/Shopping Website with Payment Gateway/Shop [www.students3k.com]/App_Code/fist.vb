Imports Microsoft.VisualBasic

Public Class fist

End Class
