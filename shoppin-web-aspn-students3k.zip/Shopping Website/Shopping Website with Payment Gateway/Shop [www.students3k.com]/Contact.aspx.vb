
Partial Class Howtobuy
    Inherits System.Web.UI.Page

End Class
